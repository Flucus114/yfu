# Iron Origins (addon do Iron's Spells 'n Spellbooks) — Forge 1.20.1

## O que tem
- **Raças** (Humano, Elfo, Anão, Orc, Tiefling): bônus/penalidades de mana, poder mágico, vida, armadura, dano.
- **Classes** (Mago, Guerreiro, Clérigo, Ladino, Druida): feitiço inicial (pergaminho), roupas básicas de couro tingido, stats.
- Escolha única ao entrar (tela abre sozinha no 1º login). Dados salvos no player e mantidos após a morte.
- **Árvore de habilidades** (tecla K): mana I–III, poder mágico I–II e 3 feitiços por classe (entregues como pergaminho). Pontos: +1 por nível de XP, +3 por boss.
- **Livros/pergaminhos do Iron's removidos de TODOS os baús** (global loot modifier). Só vêm de bosses (pergaminho aleatório, nv 2–4) ou da árvore.
- **Novas magias**: Pele de Casca (Druida/natureza) e Grito de Guerra (Guerreiro/Clérigo).
- **Cozinheiro**: 6 peixes exclusivos por bioma (oceano quente/morno/gelado/profundo, rio, pântano). Defumador/fogueira cozinham. Comer cozido dá buff que escala com o nível.
- **Arquiteto de Golens**: peças por material (pedra→diamante) × slot (cabeça=armadura, torso=vida, braços=dano, pernas=velocidade) + núcleo (fogo/gelo/arcano). Use a Varinha do Arquiteto no chão. Materiais melhores exigem nível de Arquiteto.

## ANTES DE COMPILAR (importante)
Não consegui compilar nem testar aqui (sem rede). Verifique:
1. `build.gradle`: coordenada/versão do Iron's e URL do maven.
2. IDs de magias em `SkillTree.classSpells`/`PlayerClass` (ex.: `irons_spellbooks:fang_strike`, `guiding_bolt`) e IDs de bosses em `CommonEvents.IRON_BOSSES`.
3. API do Iron's mudou entre versões: `ISpellContainer.createScrollContainer`, `SpellRegistry.none()/getEnabledSpells()/SPELL_REGISTRY_KEY`, `AttributeRegistry.*`, e a assinatura de `AbstractSpell.onCast` nas magias novas.
4. Texturas são placeholders coloridos; troque em `assets/ironorigins/textures`.
