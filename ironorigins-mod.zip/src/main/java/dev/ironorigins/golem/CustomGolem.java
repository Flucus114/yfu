package dev.ironorigins.golem;

import dev.ironorigins.Logic;
import dev.ironorigins.golem.GolemParts.*;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.level.Level;

/** Golem montado a partir de peças; stats derivados dos materiais, núcleo dá efeito especial. */
public class CustomGolem extends IronGolem {
    private CompoundTag parts = new CompoundTag();
    private Core core;

    public CustomGolem(EntityType<? extends IronGolem> type, Level level) { super(type, level); }

    public void setParts(Map<Slot, Mat> m, Core c) {
        parts = new CompoundTag();
        m.forEach((s, mat) -> parts.putString(s.id, mat.id));
        if (c != null) parts.putString("core", c.id);
        applyParts();
        setHealth(getMaxHealth());
    }

    private void applyParts() {
        core = Core.byId(parts.getString("core"));
        Mat head = Mat.byId(parts.getString("head")), torso = Mat.byId(parts.getString("torso")),
            arms = Mat.byId(parts.getString("arms")), legs = Mat.byId(parts.getString("legs"));
        Logic.put(this, () -> Attributes.ARMOR, "golem_head", head == null ? 0 : head.armor, Operation.ADDITION);
        Logic.put(this, () -> Attributes.MAX_HEALTH, "golem_torso", torso == null ? 0 : torso.hp, Operation.ADDITION);
        Logic.put(this, () -> Attributes.ATTACK_DAMAGE, "golem_arms", arms == null ? 0 : arms.dmg, Operation.ADDITION);
        Logic.put(this, () -> Attributes.MOVEMENT_SPEED, "golem_legs", legs == null ? 0 : legs.speed, Operation.MULTIPLY_BASE);
    }

    @Override public boolean doHurtTarget(Entity t) {
        boolean ok = super.doHurtTarget(t);
        if (ok && core != null && t instanceof LivingEntity le) {
            switch (core) {
                case FIRE -> le.setSecondsOnFire(5);
                case FROST -> le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2));
                case ARCANE -> le.hurt(damageSources().magic(), 5.0F);
            }
        }
        return ok;
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.put("OriginsParts", parts); }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("OriginsParts")) { parts = tag.getCompound("OriginsParts"); applyParts(); }
    }
}
