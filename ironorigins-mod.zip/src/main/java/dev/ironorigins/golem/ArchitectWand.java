package dev.ironorigins.golem;

import dev.ironorigins.Logic;
import dev.ironorigins.ModEntities;
import dev.ironorigins.data.PlayerData;
import dev.ironorigins.golem.GolemParts.*;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;

/** Varinha do Arquiteto: usa no chão. Consome a 1ª peça de cada slot do inventário (você escolhe a ordem) + núcleo opcional. */
public class ArchitectWand extends Item {
    public ArchitectWand() { super(new Item.Properties().stacksTo(1)); }

    @Override public InteractionResult useOn(UseOnContext ctx) {
        Player p = ctx.getPlayer();
        if (ctx.getLevel().isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
        EnumMap<Slot, Mat> parts = new EnumMap<>(Slot.class);
        Core core = null;
        List<ItemStack> used = new ArrayList<>();
        for (ItemStack s : sp.getInventory().items) {
            if (s.getItem() instanceof PartItem pi && !parts.containsKey(pi.slot)) { parts.put(pi.slot, pi.mat); used.add(s); }
            else if (s.getItem() instanceof CoreItem ci && core == null) { core = ci.core; used.add(s); }
        }
        if (parts.size() < 4) { sp.displayClientMessage(Component.translatable("msg.ironorigins.golem_missing"), true); return InteractionResult.FAIL; }
        int lvl = PlayerData.level(sp, "golem");
        for (Mat m : parts.values()) if (m.level > lvl) {
            sp.displayClientMessage(Component.translatable("msg.ironorigins.golem_level", m.level), true);
            return InteractionResult.FAIL;
        }
        used.forEach(s -> s.shrink(1));
        CustomGolem g = ModEntities.GOLEM.get().create(ctx.getLevel());
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        g.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, sp.getYRot(), 0);
        g.setPlayerCreated(true);
        g.setParts(parts, core);
        ctx.getLevel().addFreshEntity(g);
        PlayerData.addXp(sp, "golem", 15);
        Logic.sync(sp);
        return InteractionResult.CONSUME;
    }
}
