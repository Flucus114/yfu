package dev.ironorigins.loot;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.registries.ForgeRegistries;

/** Remove livros/pergaminhos do Iron's de qualquer baú (chests/*). Eles só vêm de bosses e da árvore. */
public class NoBookLoot extends LootModifier {
    public static final Supplier<Codec<NoBookLoot>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(i -> codecStart(i).apply(i, NoBookLoot::new)));

    public NoBookLoot(LootItemCondition[] c) { super(c); }

    @Override protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext ctx) {
        if (!ctx.getQueriedLootTableId().getPath().startsWith("chests/")) return loot;
        loot.removeIf(s -> {
            ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
            return id != null && id.getNamespace().equals("irons_spellbooks")
                    && (id.getPath().contains("book") || id.getPath().equals("scroll"));
        });
        return loot;
    }

    @Override public Codec<? extends IGlobalLootModifier> codec() { return CODEC.get(); }
}
