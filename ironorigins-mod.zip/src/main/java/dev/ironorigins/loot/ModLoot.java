package dev.ironorigins.loot;

import com.mojang.serialization.Codec;
import dev.ironorigins.IronOrigins;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public final class ModLoot {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> GLM =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, IronOrigins.MODID);
    static { GLM.register("no_book_chests", NoBookLoot.CODEC); }
}
