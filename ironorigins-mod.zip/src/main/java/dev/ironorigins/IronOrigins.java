package dev.ironorigins;

import dev.ironorigins.loot.ModLoot;
import dev.ironorigins.net.Net;
import dev.ironorigins.spell.ModSpells;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(IronOrigins.MODID)
public class IronOrigins {
    public static final String MODID = "ironorigins";

    public IronOrigins() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModLoot.GLM.register(bus);
        ModSpells.SPELLS.register(bus);
        Net.init();
        MinecraftForge.EVENT_BUS.register(new CommonEvents());
    }
}
