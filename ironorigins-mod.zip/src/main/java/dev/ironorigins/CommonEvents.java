package dev.ironorigins;

import dev.ironorigins.data.PlayerData;
import dev.ironorigins.net.Net;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import java.util.List;
import java.util.Set;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerXpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

public class CommonEvents {
    private static final Set<String> IRON_BOSSES = Set.of("dead_king", "keeper", "citadel_keeper", "fire_boss"); // confira os IDs reais no Iron's

    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent e) { init(e.getEntity()); }
    @SubscribeEvent public void respawn(PlayerEvent.PlayerRespawnEvent e) { init(e.getEntity()); }

    private void init(Player pl) {
        if (!(pl instanceof ServerPlayer p)) return;
        if (PlayerData.race(p) == null) Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new Net.OpenSelect());
        else { Logic.refresh(p); Logic.sync(p); }
    }

    @SubscribeEvent public void clone(PlayerEvent.Clone e) {
        if (!e.isWasDeath()) return;
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains(Player.PERSISTED_NBT_TAG))
            e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG, old.getCompound(Player.PERSISTED_NBT_TAG).copy());
    }

    /** +1 ponto de habilidade por nível de XP ganho. */
    @SubscribeEvent public void levelUp(PlayerXpEvent.LevelChange e) {
        if (e.getLevels() > 0 && e.getEntity() instanceof ServerPlayer p && PlayerData.cls(p) != null) {
            PlayerData.addPoints(p, e.getLevels());
            Logic.sync(p);
        }
    }

    /** Bosses: +3 pontos e um pergaminho aleatório (único jeito, com a árvore, de conseguir feitiços). */
    @SubscribeEvent public void bossDrops(LivingDropsEvent e) {
        LivingEntity v = e.getEntity();
        var key = ForgeRegistries.ENTITY_TYPES.getKey(v.getType());
        boolean boss = v instanceof EnderDragon || v instanceof WitherBoss || v.getType().is(Tags.EntityTypes.BOSSES)
                || (key != null && key.getNamespace().equals("irons_spellbooks") && IRON_BOSSES.contains(key.getPath()));
        Entity src = e.getSource().getEntity();
        if (!boss || !(src instanceof ServerPlayer sp)) return;
        PlayerData.addPoints(sp, 3);
        Logic.sync(sp);
        List<AbstractSpell> all = SpellRegistry.getEnabledSpells();
        if (all.isEmpty()) return;
        AbstractSpell s = all.get(v.getRandom().nextInt(all.size()));
        int lvl = Math.min(s.getMaxLevel(), 2 + v.getRandom().nextInt(3));
        ItemStack st = Logic.scroll(s.getSpellId(), lvl);
        if (!st.isEmpty()) e.getDrops().add(new ItemEntity(v.level(), v.getX(), v.getY(), v.getZ(), st));
        sp.sendSystemMessage(Component.translatable("msg.ironorigins.boss"));
    }

    /** Cozinheiro: peixes raros por bioma. Quanto maior o nível, maior a chance. */
    @SubscribeEvent public void fished(ItemFishedEvent e) {
        Player pl = e.getHookEntity().getPlayerOwner();
        if (!(pl instanceof ServerPlayer sp)) return;
        String biome = pl.level().getBiome(e.getHookEntity().blockPosition()).unwrapKey().map(k -> k.location().getPath()).orElse("");
        Fish f = Fish.forBiome(biome);
        if (f == null) return;
        int lvl = PlayerData.level(sp, "cook");
        NonNullList<ItemStack> d = e.getDrops();
        if (!d.isEmpty() && d.get(0).is(ItemTags.FISHES) && sp.getRandom().nextFloat() < 0.35F + 0.03F * lvl) {
            d.set(0, new ItemStack(ModItems.RAW.get(f).get()));
            PlayerData.addXp(sp, "cook", 6);
            Logic.sync(sp);
        }
    }

    /** Comer peixe cozido dá buff que cresce com o nível de Cozinheiro. */
    @SubscribeEvent public void eaten(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        for (Fish f : Fish.values()) {
            if (e.getItem().is(ModItems.COOKED.get(f).get())) {
                int lvl = PlayerData.level(sp, "cook");
                sp.addEffect(new MobEffectInstance(f.effect, 600 + 200 * lvl, Math.min(lvl / 4, 2)));
                PlayerData.addXp(sp, "cook", 3);
                Logic.sync(sp);
            }
        }
    }
}
