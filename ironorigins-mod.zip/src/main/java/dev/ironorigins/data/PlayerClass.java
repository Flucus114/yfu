package dev.ironorigins.data;

import static dev.ironorigins.data.Bonus.add;
import static dev.ironorigins.data.Bonus.mult;

import io.redspace.ironsspellbooks.api.registry.AttributeRegistry;
import java.util.List;
import net.minecraft.world.entity.ai.attributes.Attributes;

public enum PlayerClass {
    MAGE("mage", "irons_spellbooks:magic_missile", add(AttributeRegistry.MAX_MANA, 100), mult(AttributeRegistry.SPELL_POWER, 0.05)),
    WARRIOR("warrior", "irons_spellbooks:haste", add(() -> Attributes.MAX_HEALTH, 6), add(() -> Attributes.ARMOR, 2), add(() -> Attributes.ATTACK_DAMAGE, 1)),
    CLERIC("cleric", "irons_spellbooks:heal", add(AttributeRegistry.MAX_MANA, 60), add(() -> Attributes.MAX_HEALTH, 2)),
    ROGUE("rogue", "irons_spellbooks:invisibility", mult(() -> Attributes.MOVEMENT_SPEED, 0.05), add(() -> Attributes.ATTACK_DAMAGE, 1), add(AttributeRegistry.MAX_MANA, 30)),
    DRUID("druid", "ironorigins:bark_skin", add(AttributeRegistry.MAX_MANA, 80), mult(AttributeRegistry.NATURE_SPELL_POWER, 0.08));

    public final String id;
    public final String startSpell;
    public final List<Bonus> bonuses;

    PlayerClass(String id, String startSpell, Bonus... b) { this.id = id; this.startSpell = startSpell; this.bonuses = List.of(b); }

    public static PlayerClass byId(String id) {
        for (PlayerClass c : values()) if (c.id.equals(id)) return c;
        return null;
    }
}
