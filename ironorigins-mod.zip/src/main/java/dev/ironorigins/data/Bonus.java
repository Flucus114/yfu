package dev.ironorigins.data;

import java.util.function.Supplier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;

public record Bonus(Supplier<Attribute> attr, double amount, Operation op) {
    public static Bonus add(Supplier<Attribute> a, double v) { return new Bonus(a, v, Operation.ADDITION); }
    public static Bonus mult(Supplier<Attribute> a, double v) { return new Bonus(a, v, Operation.MULTIPLY_BASE); }
}
