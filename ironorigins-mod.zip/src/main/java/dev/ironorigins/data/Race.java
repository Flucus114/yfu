package dev.ironorigins.data;

import static dev.ironorigins.data.Bonus.add;
import static dev.ironorigins.data.Bonus.mult;

import io.redspace.ironsspellbooks.api.registry.AttributeRegistry;
import java.util.List;
import net.minecraft.world.entity.ai.attributes.Attributes;

public enum Race {
    HUMAN("human", add(AttributeRegistry.MAX_MANA, 50), mult(AttributeRegistry.SPELL_POWER, 0.03)),
    ELF("elf", add(AttributeRegistry.MAX_MANA, 100), mult(AttributeRegistry.SPELL_POWER, 0.08), add(() -> Attributes.MAX_HEALTH, -4)),
    DWARF("dwarf", add(() -> Attributes.ARMOR, 3), add(() -> Attributes.MAX_HEALTH, 6), add(AttributeRegistry.MAX_MANA, -50)),
    ORC("orc", add(() -> Attributes.MAX_HEALTH, 8), add(() -> Attributes.ATTACK_DAMAGE, 2), mult(AttributeRegistry.SPELL_POWER, -0.05)),
    TIEFLING("tiefling", add(AttributeRegistry.MAX_MANA, 75), mult(AttributeRegistry.FIRE_SPELL_POWER, 0.10), add(() -> Attributes.MAX_HEALTH, -2));

    public final String id;
    public final List<Bonus> bonuses;

    Race(String id, Bonus... b) { this.id = id; this.bonuses = List.of(b); }

    public static Race byId(String id) {
        for (Race r : values()) if (r.id.equals(id)) return r;
        return null;
    }
}
