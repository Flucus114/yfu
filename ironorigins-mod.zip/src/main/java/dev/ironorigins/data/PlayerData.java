package dev.ironorigins.data;

import dev.ironorigins.IronOrigins;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

/** Dados do mod guardados no PlayerPersisted (sobrevivem à morte). */
public final class PlayerData {
    private PlayerData() {}

    public static CompoundTag root(Player p) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains(Player.PERSISTED_NBT_TAG)) pd.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = pd.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(IronOrigins.MODID)) persisted.put(IronOrigins.MODID, new CompoundTag());
        return persisted.getCompound(IronOrigins.MODID);
    }

    public static Race race(Player p) { return Race.byId(root(p).getString("race")); }
    public static PlayerClass cls(Player p) { return PlayerClass.byId(root(p).getString("class")); }
    public static void setRace(Player p, Race r) { root(p).putString("race", r.id); }
    public static void setClass(Player p, PlayerClass c) { root(p).putString("class", c.id); }

    public static int points(Player p) { return root(p).getInt("points"); }
    public static void addPoints(Player p, int n) { root(p).putInt("points", Math.max(0, points(p) + n)); }

    public static Set<String> unlocked(Player p) {
        Set<String> s = new HashSet<>();
        for (Tag t : root(p).getList("unlocked", Tag.TAG_STRING)) s.add(t.getAsString());
        return s;
    }
    public static void unlock(Player p, String id) {
        ListTag l = root(p).getList("unlocked", Tag.TAG_STRING);
        l.add(StringTag.valueOf(id));
        root(p).put("unlocked", l);
    }

    public static int xp(Player p, String job) { return root(p).getInt("xp_" + job); }
    public static void addXp(Player p, String job, int n) { root(p).putInt("xp_" + job, xp(p, job) + n); }
    public static int level(int xp) { return (int) Math.sqrt(xp / 15.0); }
    public static int level(Player p, String job) { return level(xp(p, job)); }
}
