package dev.ironorigins.data;

import java.util.ArrayList;
import java.util.List;

/** Árvore de habilidades: tronco comum (mana/poder) + ramo de feitiços da classe. */
public final class SkillTree {
    private SkillTree() {}

    public record Node(String id, String name, int cost, String parent, double mana, double power, String spell, int spellLevel) {}

    public static String[] classSpells(PlayerClass c) {
        return switch (c) {
            case MAGE -> new String[] {"irons_spellbooks:magic_missile", "irons_spellbooks:fireball", "irons_spellbooks:lightning_bolt"};
            case WARRIOR -> new String[] {"irons_spellbooks:haste", "ironorigins:war_cry", "irons_spellbooks:blood_slash"};
            case CLERIC -> new String[] {"irons_spellbooks:heal", "irons_spellbooks:guiding_bolt", "ironorigins:war_cry"};
            case ROGUE -> new String[] {"irons_spellbooks:invisibility", "irons_spellbooks:blink", "irons_spellbooks:teleport"};
            case DRUID -> new String[] {"ironorigins:bark_skin", "irons_spellbooks:root", "irons_spellbooks:poison_arrow"};
        };
    }

    public static List<Node> nodes(PlayerClass c) {
        List<Node> l = new ArrayList<>();
        l.add(new Node("mana_1", "Reservas Arcanas I (+50 mana)", 1, null, 50, 0, null, 0));
        l.add(new Node("mana_2", "Reservas Arcanas II (+100 mana)", 2, "mana_1", 100, 0, null, 0));
        l.add(new Node("mana_3", "Reservas Arcanas III (+150 mana)", 3, "mana_2", 150, 0, null, 0));
        l.add(new Node("power_1", "Foco Mágico I (+5% poder)", 2, "mana_1", 0, 0.05, null, 0));
        l.add(new Node("power_2", "Foco Mágico II (+10% poder)", 3, "power_1", 0, 0.10, null, 0));
        String[] sp = classSpells(c);
        for (int i = 0; i < sp.length; i++) {
            l.add(new Node("spell_" + i, "Feitiço: " + sp[i].substring(sp[i].indexOf(':') + 1), 2 + i,
                    i == 0 ? "mana_1" : "spell_" + (i - 1), 0, 0, sp[i], 1 + i));
        }
        return l;
    }

    public static Node find(PlayerClass c, String id) {
        for (Node n : nodes(c)) if (n.id().equals(id)) return n;
        return null;
    }
}
