package dev.ironorigins;

import dev.ironorigins.data.PlayerClass;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.item.*;

/** Roupas e itens BEM básicos de cada classe. */
public final class Kit {
    private Kit() {}

    private static ItemStack dyed(Item i, int color) {
        ItemStack s = new ItemStack(i);
        ((DyeableLeatherItem) i).setColor(s, color);
        return s;
    }

    private static void robe(List<ItemStack> l, int color) {
        l.add(dyed(Items.LEATHER_HELMET, color));
        l.add(dyed(Items.LEATHER_CHESTPLATE, color));
        l.add(dyed(Items.LEATHER_LEGGINGS, color));
        l.add(dyed(Items.LEATHER_BOOTS, color));
    }

    public static List<ItemStack> items(PlayerClass c) {
        List<ItemStack> l = new ArrayList<>();
        switch (c) {
            case MAGE -> { robe(l, 0x5A3EA8); l.add(new ItemStack(Items.STICK)); }
            case WARRIOR -> { robe(l, 0x8B2E2E); l.add(new ItemStack(Items.STONE_SWORD)); l.add(new ItemStack(Items.SHIELD)); }
            case CLERIC -> { robe(l, 0xF2E6B8); l.add(new ItemStack(Items.WOODEN_SWORD)); }
            case ROGUE -> { robe(l, 0x2B2B33); l.add(new ItemStack(Items.WOODEN_SWORD)); l.add(new ItemStack(Items.BOW)); l.add(new ItemStack(Items.ARROW, 16)); }
            case DRUID -> { robe(l, 0x3E7D3A); l.add(new ItemStack(Items.WOODEN_HOE)); l.add(new ItemStack(Items.WHEAT_SEEDS, 8)); }
        }
        l.add(new ItemStack(Items.BREAD, 8));
        return l;
    }
}
