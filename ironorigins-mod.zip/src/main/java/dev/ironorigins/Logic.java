package dev.ironorigins;

import dev.ironorigins.data.*;
import dev.ironorigins.net.Net;
import io.redspace.ironsspellbooks.api.registry.AttributeRegistry;
import io.redspace.ironsspellbooks.api.registry.SpellRegistry;
import io.redspace.ironsspellbooks.api.spells.AbstractSpell;
import io.redspace.ironsspellbooks.api.spells.ISpellContainer;
import io.redspace.ironsspellbooks.registries.ItemRegistry;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraftforge.network.PacketDistributor;

public final class Logic {
    private Logic() {}

    public static void sync(ServerPlayer p) {
        Race r = PlayerData.race(p);
        PlayerClass c = PlayerData.cls(p);
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new Net.Sync(
                r == null ? -1 : r.ordinal(), c == null ? -1 : c.ordinal(), PlayerData.points(p),
                PlayerData.xp(p, "cook"), PlayerData.xp(p, "golem"), new ArrayList<>(PlayerData.unlocked(p))));
    }

    public static void put(LivingEntity e, Supplier<Attribute> a, String key, double v, Operation op) {
        AttributeInstance i = e.getAttribute(a.get());
        if (i == null) return;
        UUID id = UUID.nameUUIDFromBytes((IronOrigins.MODID + ":" + key).getBytes(StandardCharsets.UTF_8));
        i.removeModifier(id);
        if (v != 0) i.addPermanentModifier(new AttributeModifier(id, key, v, op));
    }

    private static void apply(ServerPlayer p, String src, List<Bonus> bs) {
        for (int i = 0; i < bs.size(); i++) put(p, bs.get(i).attr(), src + "_" + i, bs.get(i).amount(), bs.get(i).op());
    }

    /** Reaplica todos os modificadores (raça, classe, árvore). Idempotente. */
    public static void refresh(ServerPlayer p) {
        Race r = PlayerData.race(p);
        PlayerClass c = PlayerData.cls(p);
        if (r != null) apply(p, "race_" + r.id, r.bonuses);
        if (c != null) {
            apply(p, "class_" + c.id, c.bonuses);
            Set<String> u = PlayerData.unlocked(p);
            for (SkillTree.Node n : SkillTree.nodes(c)) {
                if (!u.contains(n.id())) continue;
                put(p, AttributeRegistry.MAX_MANA, "node_" + n.id() + "_m", n.mana(), Operation.ADDITION);
                put(p, AttributeRegistry.SPELL_POWER, "node_" + n.id() + "_p", n.power(), Operation.MULTIPLY_BASE);
            }
        }
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    public static ItemStack scroll(String id, int level) {
        AbstractSpell s = SpellRegistry.getSpell(new ResourceLocation(id));
        if (s == null || s == SpellRegistry.none()) return ItemStack.EMPTY;
        ItemStack st = new ItemStack(ItemRegistry.SCROLL.get());
        ISpellContainer.createScrollContainer(s, level, st);
        return st;
    }

    public static void give(ServerPlayer p, ItemStack s) {
        if (!s.isEmpty() && !p.getInventory().add(s)) p.drop(s, false);
    }

    public static void choose(ServerPlayer p, int ri, int ci) {
        if (PlayerData.race(p) != null || PlayerData.cls(p) != null) return; // escolha única
        if (ri < 0 || ri >= Race.values().length || ci < 0 || ci >= PlayerClass.values().length) return;
        Race r = Race.values()[ri];
        PlayerClass c = PlayerClass.values()[ci];
        PlayerData.setRace(p, r);
        PlayerData.setClass(p, c);
        PlayerData.addPoints(p, 1);
        for (ItemStack s : Kit.items(c)) {
            EquipmentSlot slot = LivingEntity.getEquipmentSlotForItem(s);
            if (slot.getType() == EquipmentSlot.Type.ARMOR && p.getItemBySlot(slot).isEmpty()) p.setItemSlot(slot, s);
            else give(p, s);
        }
        give(p, scroll(c.startSpell, 1));
        refresh(p);
        p.setHealth(p.getMaxHealth());
        p.sendSystemMessage(Component.translatable("msg.ironorigins.chosen",
                Component.translatable("race.ironorigins." + r.id), Component.translatable("class.ironorigins." + c.id)));
        sync(p);
    }

    public static void unlock(ServerPlayer p, String id) {
        PlayerClass c = PlayerData.cls(p);
        if (c == null) return;
        SkillTree.Node n = SkillTree.find(c, id);
        Set<String> u = PlayerData.unlocked(p);
        if (n == null || u.contains(id) || PlayerData.points(p) < n.cost()) return;
        if (n.parent() != null && !u.contains(n.parent())) return;
        PlayerData.addPoints(p, -n.cost());
        PlayerData.unlock(p, id);
        if (n.spell() != null) give(p, scroll(n.spell(), n.spellLevel()));
        refresh(p);
        sync(p);
    }
}
