package dev.ironorigins.client;

import dev.ironorigins.net.Net;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;

public final class ClientData {
    public static int race = -1, cls = -1, points, cook, golem;
    public static Set<String> unlocked = new HashSet<>();

    public static void accept(Net.Sync s) {
        race = s.race(); cls = s.cls(); points = s.points(); cook = s.cook(); golem = s.golem();
        unlocked = new HashSet<>(s.unlocked());
        var scr = Minecraft.getInstance().screen;
        if (scr instanceof TreeScreen t) t.rebuild();
        if (scr instanceof SelectScreen && race >= 0) scr.onClose();
    }
}
