package dev.ironorigins.client;

import dev.ironorigins.data.PlayerClass;
import dev.ironorigins.data.Race;
import dev.ironorigins.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SelectScreen extends Screen {
    private int race = 0, cls = 0;

    public SelectScreen() { super(Component.translatable("screen.ironorigins.select")); }

    @Override protected void init() {
        int cx = width / 2;
        Race[] rs = Race.values();
        for (int i = 0; i < rs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(race == i ? "> " : "").append(Component.translatable("race.ironorigins." + rs[i].id)),
                    b -> { race = idx; rebuildWidgets(); }).bounds(cx - 210, 50 + i * 24, 200, 20).build());
        }
        PlayerClass[] cs = PlayerClass.values();
        for (int i = 0; i < cs.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(cls == i ? "> " : "").append(Component.translatable("class.ironorigins." + cs[i].id)),
                    b -> { cls = idx; rebuildWidgets(); }).bounds(cx + 10, 50 + i * 24, 200, 20).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.ironorigins.confirm"),
                b -> Net.CH.sendToServer(new Net.Choose(race, cls))).bounds(cx - 60, height - 40, 120, 20).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 20, 0xFFFFFF);
        super.render(g, mx, my, pt);
        g.drawCenteredString(font, Component.translatable("race.ironorigins." + Race.values()[race].id + ".desc"), width / 2, height - 90, 0xFFD27F);
        g.drawCenteredString(font, Component.translatable("class.ironorigins." + PlayerClass.values()[cls].id + ".desc"), width / 2, height - 70, 0x9FE3FF);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
