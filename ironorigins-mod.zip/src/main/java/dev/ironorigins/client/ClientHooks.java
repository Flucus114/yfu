package dev.ironorigins.client;

import net.minecraft.client.Minecraft;

public final class ClientHooks {
    public static void openSelect() { Minecraft.getInstance().setScreen(new SelectScreen()); }
    public static void openTree() { if (ClientData.cls >= 0) Minecraft.getInstance().setScreen(new TreeScreen()); }
}
