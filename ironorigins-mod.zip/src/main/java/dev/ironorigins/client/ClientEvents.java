package dev.ironorigins.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.ironorigins.IronOrigins;
import dev.ironorigins.ModEntities;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    public static final KeyMapping TREE = new KeyMapping("key.ironorigins.tree", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.ironorigins");

    @Mod.EventBusSubscriber(modid = IronOrigins.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent public static void keys(RegisterKeyMappingsEvent e) { e.register(TREE); }
        @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(ModEntities.GOLEM.get(), IronGolemRenderer::new);
        }
    }

    @Mod.EventBusSubscriber(modid = IronOrigins.MODID, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase == TickEvent.Phase.END && TREE.consumeClick()) ClientHooks.openTree();
        }
    }
}
