package dev.ironorigins.client;

import dev.ironorigins.data.PlayerClass;
import dev.ironorigins.data.SkillTree;
import dev.ironorigins.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class TreeScreen extends Screen {
    public TreeScreen() { super(Component.translatable("screen.ironorigins.tree")); }

    public void rebuild() { rebuildWidgets(); }

    @Override protected void init() {
        PlayerClass c = PlayerClass.values()[ClientData.cls];
        int y = 40;
        for (SkillTree.Node n : SkillTree.nodes(c)) {
            boolean done = ClientData.unlocked.contains(n.id());
            boolean parentOk = n.parent() == null || ClientData.unlocked.contains(n.parent());
            String label = (done ? "[x] " : "") + n.name() + (done ? "" : "  (" + n.cost() + " pts)");
            Button b = Button.builder(Component.literal(label), x -> Net.CH.sendToServer(new Net.Unlock(n.id())))
                    .bounds(width / 2 - 130, y, 260, 20).build();
            b.active = !done && parentOk && ClientData.points >= n.cost();
            addRenderableWidget(b);
            y += 24;
        }
    }

    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        g.drawCenteredString(font, title, width / 2, 12, 0xFFFFFF);
        g.drawCenteredString(font, Component.translatable("screen.ironorigins.points", ClientData.points), width / 2, 26, 0xFFD27F);
        g.drawCenteredString(font, Component.translatable("screen.ironorigins.jobs", ClientData.cook, ClientData.golem), width / 2, height - 20, 0xAAAAAA);
    }
}
