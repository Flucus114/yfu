package dev.ironorigins.net;

import dev.ironorigins.IronOrigins;
import dev.ironorigins.Logic;
import dev.ironorigins.client.ClientData;
import dev.ironorigins.client.ClientHooks;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(IronOrigins.MODID, "main"), () -> V, V::equals, V::equals);

    public record OpenSelect() {}
    public record Choose(int race, int cls) {}
    public record Unlock(String id) {}
    public record Sync(int race, int cls, int points, int cook, int golem, List<String> unlocked) {}

    public static void init() {
        int i = 0;
        CH.registerMessage(i++, OpenSelect.class, (m, b) -> {}, b -> new OpenSelect(), (m, c) -> {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openSelect));
            c.get().setPacketHandled(true);
        });
        CH.registerMessage(i++, Choose.class, (m, b) -> { b.writeInt(m.race()); b.writeInt(m.cls()); },
                b -> new Choose(b.readInt(), b.readInt()), (m, c) -> {
                    c.get().enqueueWork(() -> { if (c.get().getSender() != null) Logic.choose(c.get().getSender(), m.race(), m.cls()); });
                    c.get().setPacketHandled(true);
                });
        CH.registerMessage(i++, Unlock.class, (m, b) -> b.writeUtf(m.id()), b -> new Unlock(b.readUtf(64)), (m, c) -> {
            c.get().enqueueWork(() -> { if (c.get().getSender() != null) Logic.unlock(c.get().getSender(), m.id()); });
            c.get().setPacketHandled(true);
        });
        CH.registerMessage(i++, Sync.class, (m, b) -> {
            b.writeInt(m.race()); b.writeInt(m.cls()); b.writeInt(m.points()); b.writeInt(m.cook()); b.writeInt(m.golem());
            b.writeCollection(m.unlocked(), FriendlyByteBuf::writeUtf);
        }, b -> new Sync(b.readInt(), b.readInt(), b.readInt(), b.readInt(), b.readInt(),
                new ArrayList<>(b.readCollection(ArrayList::new, buf -> buf.readUtf(64)))), (m, c) -> {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientData.accept(m)));
            c.get().setPacketHandled(true);
        });
    }
}
