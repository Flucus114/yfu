package dev.ironorigins;

import dev.ironorigins.golem.CustomGolem;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = IronOrigins.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, IronOrigins.MODID);
    public static final RegistryObject<EntityType<CustomGolem>> GOLEM = ENTITIES.register("custom_golem", () ->
            EntityType.Builder.<CustomGolem>of(CustomGolem::new, MobCategory.MISC).sized(1.4F, 2.7F).clientTrackingRange(10).build("custom_golem"));

    @SubscribeEvent public static void attributes(EntityAttributeCreationEvent e) {
        e.put(GOLEM.get(), IronGolem.createAttributes().build());
    }
}
